First off, thank you for considering contributing to 2tric!

Please keep the issues simple to read and don't repeat yourself.

Always merge into the features branch before making a pull request to the master branch.
(Your code must be reviewed before it will get merged to master)

FAQ:

Q: Why isn't something here yet?

A: Because nobody asked for it. ^^
