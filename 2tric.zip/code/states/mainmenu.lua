mainmenu = {}

function mainmenu:enter()
  state.switch(test)
end

function mainmenu:draw()
  
end

function mainmenu:update(dt)
  
end

return mainmenu