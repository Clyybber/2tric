editor = {}

function editor:enter()

end

function editor:draw()

end

function editor:update(dt)
  
end

return editor